"""WireGuard research dashboard package."""
