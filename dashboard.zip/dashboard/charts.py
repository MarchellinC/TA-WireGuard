"""Reusable interactive charts for the WireGuard research dashboard."""

from __future__ import annotations

import pandas as pd
import streamlit as st

try:
    import plotly.express as px
    import plotly.graph_objects as go

    PLOTLY_AVAILABLE = True
except ImportError:  # Streamlit's bundled Altair remains a local fallback.
    import altair as alt

    PLOTLY_AVAILABLE = False


PINKS = {"BASELINE": "#EFA3BD", "WIREGUARD": "#A76F88"}
SERIES_PALETTE = ["#D981A2", "#A76F88", "#F0B4C9"]


def _label(value: float, decimals: int) -> str:
    return f"{value:.{decimals}f}"


def _loss_range(values: pd.Series) -> list[float]:
    maximum = float(values.max()) if not values.empty else 0.0
    if maximum <= 0:
        return [0.0, 0.0001]
    return [0.0, maximum * 1.3]


def comparison_chart(
    data: pd.DataFrame,
    metric: str,
    label: str,
    unit: str,
    decimals: int,
):
    chart_data = data[["target_rate", "condition", metric]].dropna().copy()
    chart_data["Nilai"] = chart_data[metric]
    chart_data["Label"] = chart_data["Nilai"].map(lambda value: _label(value, decimals))
    chart_data["condition"] = chart_data["condition"].replace(
        {"BASELINE": "Baseline", "WIREGUARD": "WireGuard"}
    )
    if PLOTLY_AVAILABLE:
        color_map = {"Baseline": PINKS["BASELINE"], "WireGuard": PINKS["WIREGUARD"]}
        fig = px.bar(
            chart_data,
            x="target_rate",
            y="Nilai",
            color="condition",
            barmode="group",
            text="Label",
            category_orders={"target_rate": ["10M", "50M", "100M"], "condition": ["Baseline", "WireGuard"]},
            color_discrete_map=color_map,
            labels={"target_rate": "Target Bitrate", "Nilai": f"{label} ({unit})", "condition": "Kondisi"},
        )
        fig.update_traces(textposition="outside", cliponaxis=False)
        fig.update_layout(
            height=430,
            margin=dict(t=35, b=30, l=20, r=20),
            legend_title_text="Kondisi",
            plot_bgcolor="white",
            paper_bgcolor="white",
        )
        if metric == "packet_loss_percent":
            fig.update_yaxes(range=_loss_range(chart_data["Nilai"]), tickformat=".6f")
        else:
            fig.update_yaxes(rangemode="tozero")
        return fig

    y_scale = (
        alt.Scale(domain=_loss_range(chart_data["Nilai"]))
        if metric == "packet_loss_percent"
        else alt.Scale(zero=True)
    )
    chart = (
        alt.Chart(chart_data)
        .mark_bar()
        .encode(
            x=alt.X("target_rate:N", sort=["10M", "50M", "100M"], title="Target Bitrate"),
            xOffset="condition:N",
            y=alt.Y("Nilai:Q", title=f"{label} ({unit})", scale=y_scale),
            color=alt.Color("condition:N", scale=alt.Scale(domain=["Baseline", "WireGuard"], range=[*PINKS.values()]), title="Kondisi"),
            tooltip=["target_rate", "condition", alt.Tooltip("Nilai:Q", format=f".{decimals}f")],
        )
        .properties(height=390)
    )
    labels = chart.mark_text(dy=-7, color="#59434D", fontSize=11).encode(text="Label:N")
    return chart + labels


def trend_chart(
    data: pd.DataFrame,
    metric: str,
    label: str,
    unit: str,
    decimals: int,
    factor: str,
    condition: str,
):
    chart_data = data[data["condition"] == condition].dropna(subset=[metric]).copy()
    chart_data["Nilai"] = chart_data[metric]
    chart_data["Label"] = chart_data["Nilai"].map(lambda value: _label(value, decimals))
    chart_data["Target Bitrate (Mbps)"] = chart_data["target_rate"].map({"10M": 10, "50M": 50, "100M": 100})
    if factor == "trafik":
        x = "Target Bitrate (Mbps)"
        series = "packet_size_bytes"
        color_title = "Ukuran Paket (byte)"
        chart_data[series] = chart_data[series].astype(str)
        category_order = ["128", "512", "1024"]
    else:
        x = "packet_size_bytes"
        series = "target_rate"
        color_title = "Target Bitrate"
        category_order = ["10M", "50M", "100M"]

    if PLOTLY_AVAILABLE:
        fig = px.line(
            chart_data,
            x=x,
            y="Nilai",
            color=series,
            markers=True,
            text="Label",
            category_orders={series: category_order},
            color_discrete_sequence=SERIES_PALETTE,
            labels={x: "Target Bitrate (Mbps)" if factor == "trafik" else "Ukuran Paket (byte)", "Nilai": f"{label} ({unit})", series: color_title},
        )
        fig.update_traces(textposition="top center", cliponaxis=False)
        fig.update_layout(
            height=440,
            margin=dict(t=35, b=30, l=20, r=20),
            legend_title_text=color_title,
            plot_bgcolor="white",
            paper_bgcolor="white",
        )
        if factor == "trafik":
            fig.update_xaxes(tickmode="array", tickvals=[10, 50, 100])
        else:
            fig.update_xaxes(tickmode="array", tickvals=[128, 512, 1024])
        if metric == "packet_loss_percent":
            fig.update_yaxes(range=_loss_range(chart_data["Nilai"]), tickformat=".6f")
        return fig

    x_encoding = alt.X(f"{x}:Q", title="Target Bitrate (Mbps)" if factor == "trafik" else "Ukuran Paket (byte)")
    y_scale = (
        alt.Scale(domain=_loss_range(chart_data["Nilai"]))
        if metric == "packet_loss_percent"
        else alt.Scale(zero=False)
    )
    chart = (
        alt.Chart(chart_data)
        .mark_line(point=alt.OverlayMarkDef(filled=True, size=70))
        .encode(
            x=x_encoding,
            y=alt.Y("Nilai:Q", title=f"{label} ({unit})", scale=y_scale),
            color=alt.Color(f"{series}:N", sort=category_order, scale=alt.Scale(range=SERIES_PALETTE), title=color_title),
            tooltip=[x, series, alt.Tooltip("Nilai:Q", format=f".{decimals}f")],
        )
        .properties(height=400)
    )
    labels = chart.mark_text(dy=-10, fontSize=10).encode(text="Label:N")
    return chart + labels
