"""Soft-pink theme and shared layout styling."""

import streamlit as st


def apply_styles() -> None:
    st.markdown(
        """
        <style>
        :root { --ink:#59434D; --muted:#8B737D; --pink:#F4AFC4; --pale:#FFF7FA; }
        .stApp { background: linear-gradient(135deg, #FFF7FA 0%, #FFF0F5 54%, #FCE4EC 100%); color:var(--ink); }
        [data-testid="stSidebar"] { background:#FCE4EC; border-right:1px solid #F4D2DE; }
        [data-testid="stSidebar"] * { color:var(--ink); }
        h1,h2,h3 { color:var(--ink); letter-spacing:-0.025em; }
        p, li, label, [data-testid="stCaptionContainer"] { color:var(--muted); }
        [data-testid="stMetric"] { background:rgba(255,255,255,.82); border:1px solid #F3D9E2; padding:18px 20px; border-radius:16px; box-shadow:0 5px 16px rgba(112,69,87,.05); }
        [data-testid="stMetricLabel"] { color:var(--muted); }
        [data-testid="stMetricValue"] { color:var(--ink); }
        div[data-testid="stTabs"] button[aria-selected="true"] { color:#A76F88; border-color:#EFA3BD; }
        .hero { padding:1.35rem 1.55rem; border-radius:20px; border:1px solid #F3D9E2; background:linear-gradient(120deg,rgba(255,255,255,.94),rgba(252,228,236,.82)); margin:.5rem 0 1.2rem; }
        .hero-kicker { text-transform:uppercase; letter-spacing:.14em; color:#A76F88; font-size:.76rem; font-weight:700; }
        .hero-title { color:#59434D; font-size:clamp(1.65rem,3vw,2.3rem); line-height:1.2; font-weight:750; margin:.45rem 0; }
        .hero-copy { color:#8B737D; font-size:1rem; line-height:1.65; max-width:900px; margin:0; }
        .info-card { height:100%; background:rgba(255,255,255,.78); border:1px solid #F3D9E2; border-radius:16px; padding:1rem 1.1rem; }
        .info-card h4 { color:#59434D; margin:.1rem 0 .45rem; }
        .info-card p { color:#8B737D; margin:0; line-height:1.55; }
        .small-note { color:#8B737D; font-size:.9rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )
