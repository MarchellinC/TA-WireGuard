"""Streamlit dashboard for WireGuard transfer performance experiments."""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

# Streamlit and AppTest do not always add the script directory to sys.path.
_DASHBOARD_DIR = str(Path(__file__).resolve().parent)
if _DASHBOARD_DIR not in sys.path:
    sys.path.insert(0, _DASHBOARD_DIR)

from analysis import (
    CONDITIONS,
    METRIC_INFO,
    PACKET_SIZES,
    percent_change,
    scenario_count,
)
from charts import PLOTLY_AVAILABLE, comparison_chart, trend_chart
from data_loader import DatasetError, aggregate_dataset, load_dataset
from styles import apply_styles


st.set_page_config(
    page_title="Analisis Kinerja WireGuard",
    layout="wide",
    initial_sidebar_state="expanded",
)
apply_styles()


def hero(kicker: str, title: str, copy: str) -> None:
    st.markdown(
        f'<section class="hero"><div class="hero-kicker">{kicker}</div>'
        f'<div class="hero-title">{title}</div><p class="hero-copy">{copy}</p></section>',
        unsafe_allow_html=True,
    )


def info_card(title: str, body: str) -> None:
    st.markdown(
        f'<div class="info-card"><h4>{title}</h4><p>{body}</p></div>',
        unsafe_allow_html=True,
    )


def show_chart(chart) -> None:
    if PLOTLY_AVAILABLE:
        st.plotly_chart(
            chart,
            use_container_width=True,
            config={"displaylogo": False, "responsive": True},
        )
    else:
        st.altair_chart(chart, use_container_width=True)


def sidebar_navigation() -> str:
    with st.sidebar:
        st.markdown("<div class='hero-kicker'>Tugas Akhir</div>", unsafe_allow_html=True)
        st.markdown("## Marchellin Chenika")
        st.caption("140810230002 · Teknik Informatika")
        st.caption("FMIPA · Universitas Padjadjaran")
        st.divider()
        st.markdown("### Penelitian")
        st.caption("Objek: WireGuard VPN")
        st.caption("Lingkungan: Linux VM di VirtualBox")
        st.caption("Metode: Baseline dibandingkan dengan WireGuard")
        st.divider()
        return st.radio(
            "Navigasi",
            ["Dashboard", "Analisis Grafik", "Tentang Proyek"],
            label_visibility="collapsed",
        )


def render_dashboard(raw, valid) -> None:
    hero(
        "Dashboard penelitian",
        "Analisis Kinerja Transfer Data dengan WireGuard",
        "Perbandingan kondisi Baseline dan WireGuard pada variasi ukuran paket dan target bitrate di lingkungan Linux virtual.",
    )
    excluded = len(raw) - len(valid)
    scenario_total = scenario_count(valid)
    condition_total = int(valid["condition"].nunique())

    a, b, c, d = st.columns(4)
    a.metric("Data valid", f"{len(valid):,}", help="Status iperf3 dan receiver berhasil, dengan semua metrik utama terisi.")
    b.metric("Skenario", f"{scenario_total}", help="Kombinasi unik ukuran paket dan target bitrate pada data valid.")
    c.metric("Kondisi", f"{condition_total}", help="Kondisi eksperimen yang tercatat pada data valid.")
    d.metric("Data dikecualikan", f"{excluded:,}", help="Baris yang tidak lolos aturan validasi notebook.")

    st.markdown("### Variasi pengujian")
    x, y = st.columns(2)
    with x:
        st.metric("Ukuran paket", "128 · 512 · 1024 byte")
    with y:
        st.metric("Target bitrate", "10 · 50 · 100 Mbps")
    st.caption("Target bitrate adalah intensitas trafik yang diminta pada skenario, bukan jaminan throughput aktual.")

    st.markdown("### Parameter yang diamati")
    items = list(METRIC_INFO.values())
    for start in range(0, len(items), 3):
        columns = st.columns(3)
        for column, item in zip(columns, items[start : start + 3]):
            with column:
                info_card(item["label"], f'{item["description"]} Satuan: {item["unit"]}.')
    st.markdown("### Ringkasan kondisi")
    counts = valid.groupby("condition")["experiment_id"].nunique().reindex(CONDITIONS, fill_value=0)
    st.bar_chart(counts.rename(index={"BASELINE": "Baseline", "WIREGUARD": "WireGuard"}), color="#EFA3BD")


def render_analysis(means) -> None:
    hero(
        "Eksplorasi hasil",
        "Analisis Grafik",
        "Pilih parameter untuk membandingkan nilai rata-rata dan melihat pengaruh target trafik maupun ukuran paket. Semua agregat mengikuti pengelompokan notebook.",
    )
    if not PLOTLY_AVAILABLE:
        st.info("Grafik interaktif berjalan dalam mode Altair. Untuk Plotly, instal dependensi dari requirements.txt.")

    metric_label = st.selectbox("Parameter", [item["label"] for item in METRIC_INFO.values()])
    metric = next(key for key, item in METRIC_INFO.items() if item["label"] == metric_label)
    info = METRIC_INFO[metric]
    st.caption(info["description"])

    comparison_tab, traffic_tab, packet_tab = st.tabs(
        ["Baseline vs WireGuard", "Berdasarkan Intensitas Trafik", "Berdasarkan Ukuran Paket"]
    )
    with comparison_tab:
        st.markdown(f"#### {info['label']} menurut ukuran paket")
        size_tabs = st.tabs([f"{size} byte" for size in PACKET_SIZES])
        for tab, size in zip(size_tabs, PACKET_SIZES):
            with tab:
                data = means[means["packet_size_bytes"] == size]
                if data.empty:
                    st.info("Belum ada pasangan data untuk ukuran paket ini.")
                else:
                    show_chart(comparison_chart(data, metric, info["label"], info["unit"], info["decimals"]))
        changes = percent_change(means, metric)
        if not changes.empty:
            with st.expander("Lihat perubahan WireGuard terhadap Baseline"):
                display_changes = changes.copy()
                display_changes["packet_size_bytes"] = display_changes["packet_size_bytes"].astype(str) + " byte"
                display_changes["change_percent"] = display_changes["change_percent"].map(
                    lambda value: "—" if pd_isna(value) else f"{value:.2f}%"
                )
                display_changes = display_changes.rename(
                    columns={"packet_size_bytes": "Ukuran Paket", "target_rate": "Target Bitrate", "change_percent": "Perubahan"}
                )
                st.dataframe(display_changes, hide_index=True, use_container_width=True)

    with traffic_tab:
        st.markdown(f"#### Pengaruh target bitrate terhadap {info['label'].lower()}")
        render_trend_pair(means, metric, info, factor="trafik")

    with packet_tab:
        st.markdown(f"#### Pengaruh ukuran paket terhadap {info['label'].lower()}")
        render_trend_pair(means, metric, info, factor="ukuran")


def pd_isna(value) -> bool:
    return value != value


def render_trend_pair(means, metric, info, factor: str) -> None:
    columns = st.columns(2)
    for column, condition in zip(columns, CONDITIONS):
        with column:
            st.markdown(f"**{condition.title()}**")
            data = means[means["condition"] == condition]
            if data.empty:
                st.info("Data kondisi ini belum tersedia.")
            else:
                show_chart(trend_chart(data, metric, info["label"], info["unit"], info["decimals"], factor, condition))


def render_about(raw, valid) -> None:
    hero(
        "Informasi penelitian",
        "Tentang Proyek",
        "Eksperimen komparatif untuk memahami perubahan kinerja transfer data ketika WireGuard diterapkan pada jaringan Linux virtual.",
    )
    left, right = st.columns(2)
    with left:
        st.markdown("### Latar Belakang")
        st.write(
            "WireGuard merupakan VPN yang melindungi komunikasi melalui mekanisme enkripsi. "
            "Penerapannya dapat berkaitan dengan perubahan kinerja transfer data dan penggunaan sumber daya sistem. "
            "Dashboard ini menyajikan hasil eksperimen tanpa menambahkan data simulasi."
        )
        st.markdown("### Tujuan Penelitian")
        st.write(
            "Menganalisis dampak penerapan WireGuard terhadap kinerja transfer data pada berbagai ukuran paket "
            "dan intensitas trafik di lingkungan Linux virtual."
        )
    with right:
        st.markdown("### Lingkungan Pengujian")
        st.markdown(
            "- Dua Virtual Machine Ubuntu Linux\n"
            "- Oracle VM VirtualBox\n"
            "- Komunikasi Client dan Server\n"
            "- WireGuard sebagai VPN\n"
            "- iperf3 untuk pengujian trafik\n"
            "- ping untuk pengukuran RTT\n"
            "- top untuk pengukuran utilisasi CPU"
        )
    st.markdown("### Alur Penelitian")
    steps = [
        "Persiapan lingkungan pengujian",
        "Konfigurasi jaringan dan WireGuard",
        "Pengujian kondisi Baseline",
        "Pengujian kondisi WireGuard",
        "Pengumpulan data",
        "Preprocessing dan validasi data",
        "Analisis dan visualisasi hasil",
    ]
    cols = st.columns(4)
    for index, step in enumerate(steps):
        with cols[index % 4]:
            info_card(f"{index + 1:02d}", step)
    st.caption(f"Dataset memuat {len(raw)} baris; {len(valid)} baris memenuhi aturan validasi notebook.")


def main() -> None:
    page = sidebar_navigation()
    try:
        raw, valid = load_dataset()
        means, _stats = aggregate_dataset(valid)
    except DatasetError as exc:
        st.error(str(exc))
        st.info("Pastikan file `Client/processed_data/all_skenario3/raw_dataset.csv` tersedia dan memiliki format yang sesuai.")
        st.stop()

    if page == "Dashboard":
        render_dashboard(raw, valid)
    elif page == "Analisis Grafik":
        render_analysis(means)
    else:
        render_about(raw, valid)


if __name__ == "__main__":
    main()